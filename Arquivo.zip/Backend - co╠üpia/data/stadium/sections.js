module.exports= {
    'GrandStand':'Arquibancada',
    'Tribune': 'Tribuna',
    'Sides': 'Laterais',
    'Bench': 'Bancada'
}