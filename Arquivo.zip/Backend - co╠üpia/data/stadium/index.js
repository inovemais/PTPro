const Stadium = require('./stadium');
const StadiumService = require('./service');

const service = StadiumService(Stadium);

module.exports = service;